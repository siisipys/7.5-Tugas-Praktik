import 'komentar.dart';

class Berita {
  final int id;
  final int userId;
  final String judul;
  final String konten;
  final String? gambar;
  final String kategori;
  final String status;
  final DateTime createdAt;
  final DateTime updatedAt;
  final BeritaUser? user;
  final List<Komentar>? komentar;

  Berita({
    required this.id,
    required this.userId,
    required this.judul,
    required this.konten,
    this.gambar,
    required this.kategori,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    this.user,
    this.komentar,
  });

  factory Berita.fromJson(Map<String, dynamic> json) {
    return Berita(
      id: json['id'],
      userId: json['user_id'],
      judul: json['judul'],
      konten: json['konten'],
      gambar: json['gambar'],
      kategori: json['kategori'],
      status: json['status'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      user: json['user'] != null ? BeritaUser.fromJson(json['user']) : null,
      komentar: json['komentar'] != null
          ? (json['komentar'] as List).map((k) => Komentar.fromJson(k)).toList()
          : null,
    );
  }
}

class BeritaUser {
  final int id;
  final String name;

  BeritaUser({required this.id, required this.name});

  factory BeritaUser.fromJson(Map<String, dynamic> json) {
    return BeritaUser(
      id: json['id'],
      name: json['name'],
    );
  }
}
