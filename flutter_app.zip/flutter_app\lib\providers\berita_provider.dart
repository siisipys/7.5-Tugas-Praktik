import 'package:flutter/material.dart';
import '../models/berita.dart';
import '../models/komentar.dart';
import '../services/api_service.dart';

class BeritaProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  List<Berita> _beritaList = [];
  Berita? _selectedBerita;
  bool _isLoading = false;
  String? _errorMessage;

  List<Berita> get beritaList => _beritaList;
  Berita? get selectedBerita => _selectedBerita;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  Future<void> fetchBerita() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _beritaList = await _apiService.getBerita();
    } catch (e) {
      _errorMessage = 'Failed to load news';
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> fetchBeritaDetail(int id) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _selectedBerita = await _apiService.getBeritaDetail(id);
    } catch (e) {
      _errorMessage = 'Failed to load news detail';
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> fetchBeritaByCategory(String kategori) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _beritaList = await _apiService.getBeritaByCategory(kategori);
    } catch (e) {
      _errorMessage = 'Failed to load news';
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> searchBerita(String query) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _beritaList = await _apiService.searchBerita(query);
    } catch (e) {
      _errorMessage = 'Failed to search news';
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<bool> addKomentar(int beritaId, String isi) async {
    try {
      final response = await _apiService.addKomentar(beritaId, isi);
      if (response['success'] == true) {
        // Refresh the berita detail to get updated comments
        await fetchBeritaDetail(beritaId);
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> createBerita(String judul, String konten, String kategori) async {
    try {
      final response = await _apiService.createBerita(judul, konten, kategori);
      if (response['success'] == true) {
        await fetchBerita();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  void clearSelectedBerita() {
    _selectedBerita = null;
    notifyListeners();
  }
}
