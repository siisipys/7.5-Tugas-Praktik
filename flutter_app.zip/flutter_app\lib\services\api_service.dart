import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user.dart';
import '../models/berita.dart';
import '../models/komentar.dart';

class ApiService {
  // DEVELOPMENT URLs (pilih sesuai platform testing)
  static const String devUrlWeb = 'http://localhost:8000/api';          // Web/Desktop
  static const String devUrlEmulator = 'http://10.0.2.2:8000/api';     // Android Emulator
  static const String devUrlDevice = 'http://192.168.1.33:8000/api';   // Real Device (IP Laptop Anda)
  
  // PRODUCTION URL (Railway)
  static const String prodUrl = 'https://web-production-01d95.up.railway.app/api';
  
  // Mode: 'dev' atau 'prod'
  static const String mode = 'prod';
  
  // Platform yang digunakan saat development: 'web', 'emulator', atau 'device'
  static const String devPlatform = 'web';
  
  static String get baseUrl {
    if (mode == 'prod') {
      return prodUrl;
    } else {
      // Development mode
      switch (devPlatform) {
        case 'emulator':
          return devUrlEmulator;
        case 'device':
          return devUrlDevice;
        default:
          return devUrlWeb;
      }
    }
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);
  }

  Future<void> removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
  }

  Future<Map<String, String>> getHeaders({bool withAuth = false}) async {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (withAuth) {
      final token = await getToken();
      if (token != null) {
        headers['Authorization'] = 'Bearer $token';
      }
    }

    return headers;
  }

  // Auth Methods
  Future<Map<String, dynamic>> register(
      String name, String email, String password, String passwordConfirmation) async {
    final response = await http.post(
      Uri.parse('$baseUrl/register'),
      headers: await getHeaders(),
      body: jsonEncode({
        'name': name,
        'email': email,
        'password': password,
        'password_confirmation': passwordConfirmation,
      }),
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 201) {
      await saveToken(data['data']['token']);
    }

    return data;
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/login'),
      headers: await getHeaders(),
      body: jsonEncode({
        'email': email,
        'password': password,
      }),
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200) {
      await saveToken(data['data']['token']);
    }

    return data;
  }

  Future<void> logout() async {
    try {
      await http.post(
        Uri.parse('$baseUrl/logout'),
        headers: await getHeaders(withAuth: true),
      );
    } catch (e) {
      // Ignore errors
    }
    await removeToken();
  }

  Future<User?> getProfile() async {
    final token = await getToken();
    if (token == null) return null;

    final response = await http.get(
      Uri.parse('$baseUrl/profile'),
      headers: await getHeaders(withAuth: true),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return User.fromJson(data['data']);
    }

    return null;
  }

  // Berita Methods
  Future<List<Berita>> getBerita() async {
    final response = await http.get(
      Uri.parse('$baseUrl/berita'),
      headers: await getHeaders(),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return (data['data'] as List).map((b) => Berita.fromJson(b)).toList();
    }

    return [];
  }

  Future<Berita?> getBeritaDetail(int id) async {
    final response = await http.get(
      Uri.parse('$baseUrl/berita/$id'),
      headers: await getHeaders(),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return Berita.fromJson(data['data']);
    }

    return null;
  }

  Future<List<Berita>> getBeritaByCategory(String kategori) async {
    final response = await http.get(
      Uri.parse('$baseUrl/berita/kategori/$kategori'),
      headers: await getHeaders(),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return (data['data'] as List).map((b) => Berita.fromJson(b)).toList();
    }

    return [];
  }

  Future<List<Berita>> searchBerita(String query) async {
    final response = await http.get(
      Uri.parse('$baseUrl/search?q=$query'),
      headers: await getHeaders(),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return (data['data'] as List).map((b) => Berita.fromJson(b)).toList();
    }

    return [];
  }

  Future<Map<String, dynamic>> createBerita(
      String judul, String konten, String kategori) async {
    final response = await http.post(
      Uri.parse('$baseUrl/berita'),
      headers: await getHeaders(withAuth: true),
      body: jsonEncode({
        'judul': judul,
        'konten': konten,
        'kategori': kategori,
      }),
    );

    return jsonDecode(response.body);
  }

  // Komentar Methods
  Future<List<Komentar>> getKomentar(int beritaId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/berita/$beritaId/komentar'),
      headers: await getHeaders(),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return (data['data'] as List).map((k) => Komentar.fromJson(k)).toList();
    }

    return [];
  }

  Future<Map<String, dynamic>> addKomentar(int beritaId, String isi) async {
    final response = await http.post(
      Uri.parse('$baseUrl/berita/$beritaId/komentar'),
      headers: await getHeaders(withAuth: true),
      body: jsonEncode({'isi': isi}),
    );

    return jsonDecode(response.body);
  }

  Future<Map<String, dynamic>> deleteKomentar(int beritaId, int komentarId) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/berita/$beritaId/komentar/$komentarId'),
      headers: await getHeaders(withAuth: true),
    );

    return jsonDecode(response.body);
  }
}
