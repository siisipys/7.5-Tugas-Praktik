class Komentar {
  final int id;
  final int userId;
  final int beritaId;
  final String isi;
  final DateTime createdAt;
  final DateTime updatedAt;
  final KomentarUser? user;

  Komentar({
    required this.id,
    required this.userId,
    required this.beritaId,
    required this.isi,
    required this.createdAt,
    required this.updatedAt,
    this.user,
  });

  factory Komentar.fromJson(Map<String, dynamic> json) {
    return Komentar(
      id: json['id'],
      userId: json['user_id'],
      beritaId: json['berita_id'],
      isi: json['isi'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      user: json['user'] != null ? KomentarUser.fromJson(json['user']) : null,
    );
  }
}

class KomentarUser {
  final int id;
  final String name;

  KomentarUser({required this.id, required this.name});

  factory KomentarUser.fromJson(Map<String, dynamic> json) {
    return KomentarUser(
      id: json['id'],
      name: json['name'],
    );
  }
}
